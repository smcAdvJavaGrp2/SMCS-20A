//
//  blinker.h
//  Project1
//  Nashir Janmohamed
//

#ifndef blinker_h
#define blinker_h

//#include "life.h"

#include "life.h"

class Blinker : public Life {
public:
    
    // Constructor/destructor
    Blinker(int r, int c);
    ~Blinker();
};

#endif /* blinker_h */
