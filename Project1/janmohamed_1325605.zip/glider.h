//
//  glider.h
//  Project1
//  Nashir Janmohamed
//

#ifndef glider_h
#define glider_h

#include "life.h"

class Glider : public Life {
public:
    // Constructor/destructor
    Glider(int r, int c);
    ~Glider();
};

#endif /* glider_h */
